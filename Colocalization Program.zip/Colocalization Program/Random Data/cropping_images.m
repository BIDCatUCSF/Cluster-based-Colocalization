clear all; close all;

%This is a program written to crop two sets of images from two different
%data to the same size
green_path='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Random Data\488nm\ErodedBoundaryImagestmp\MaskBoundErode';
red_path='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Random Data\642nm\ErodedBoundaryImagestmp\MaskBoundErode';

green_path_save='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Random Data\488nm\ErodedBoundaryImages\MaskBoundErode';
red_path_save='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Random Data\642nm\ErodedBoundaryImages\MaskBoundErode';

ns=49; 
ne=91;


for i=ns:ne
   
    %reading in images
    ig=imread(strcat(green_path,num2str(i),'.tif'));
    ir=imread(strcat(red_path,num2str(i),'.tif'));
    
    %binary images
    bin_g=zeros(size(ig));
    bin_r=zeros(size(ir));
    idx_g=find(ig>0);
    idx_r=find(ir>0);
    bin_g(idx_g)=1;
    bin_r(idx_r)=1;
    
    %centroid
    sg_tmp=regionprops(bin_g,'centroid')
    sr_tmp=regionprops(bin_r,'centroid')
    sg=sg_tmp.Centroid;
    sr=sr_tmp.Centroid;
    
    %cropping
    ig_crop=imcrop(ig,[sg(1)-55,sg(2)-55,110,110]);
    ir_crop=imcrop(ir,[sr(1)-55,sr(2)-55,110,110]);

    %saving 
    imwrite(ig_crop,strcat(green_path_save,num2str(i),'.tif'));
    imwrite(ir_crop,strcat(red_path_save,num2str(i),'.tif'));
    
    %clear statements
    clear ig; clear ir; clear bin_r; clear bin_g; clear idx_g; clear idx_r;
    clear sg_tmp; clear sr_tmp; clear sg; clear sr;
    clear ig_crop; clear ir_crop;
    
    
end






























