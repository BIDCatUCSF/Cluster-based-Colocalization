function[im_return]=invert_mask(act_image,the_mask)

%positive from the mask
idx1=find(the_mask>0);

if numel(idx1)==0
    
    %image to return
    im_return=zeros(size(act_image));
    im_return=double(im_return);
    im_return=im_return+1;
    
else
    %positive from image
    idx1_im=find(act_image>0);
    
    %image to return
    im_return=zeros(size(act_image));
    im_return=double(im_return);
    
    %inverting the mask;
    im_return(idx1_im)=1;
    im_return(idx1)=0;

end

ok=100










