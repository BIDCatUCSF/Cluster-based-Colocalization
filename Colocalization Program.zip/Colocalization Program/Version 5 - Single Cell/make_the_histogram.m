function[]=make_the_histogram(the_data,the_title,path_for_save_tmp)

%This is nothing but a function to plot a histogram to keep as record for
%the analysis of the colocalization of En's clustering data

%creating the necessary directory
idx_st=find(path_for_save_tmp=='\');
path_for_save=path_for_save_tmp(1:(idx_st(numel(idx_st))-1));

%bins for this histogram
nbins=[0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1];
nbins=nbins.*100;

%closing all open figures
close all;

%histogram
figure, hist(the_data(:,1),nbins); title(the_title)
xlabel('Colocalization %'); ylabel('#');
saveas(gcf,strcat(path_for_save,'the_Histogram_Coloc_Perc.png'));
saveas(gcf,strcat(path_for_save,'the_Histogram_Coloc_Perc.fig'));

%close all open figures
close all;

[y_john,x_john]=hist(the_data(:,1),nbins);
tot_entries=sum(y_john)

%the scatter plot
figure, hold on;
plot(the_data(:,2),the_data(:,1),'ko','LineWidth',1.5,'MarkerSize',12);title(the_title)
xlabel('Cluster Size'); ylabel('Colocalization %');
saveas(gcf,strcat(path_for_save,'the_ScatterPlot_Coloc_Perc.png'));
saveas(gcf,strcat(path_for_save,'the_ScatterPlot_Coloc_Perc.fig'));

%closing all open figures
















