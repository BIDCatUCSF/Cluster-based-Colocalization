function[image_back]=mask_rgb_images(image1,image2)

%both of the inputs are rgb images

image_back(:,:,1)=image1(:,:,1).*image2(:,:,1);
image_back(:,:,2)=image1(:,:,2).*image2(:,:,2);
image_back(:,:,3)=image1(:,:,3).*image2(:,:,3);














