function[max_im]=create_max_proj(im_stack)

size(im_stack)

%dimensions of image
dimA=size(im_stack,1);
dimB=size(im_stack,2);

%maximum intensity image
max_im=zeros(dimA,dimB);

for i=1:dimA
    
    for j=1:dimB
        
       
        max_im(i,j)=max(im_stack(i,j,:));
        
    end
    
    
end

