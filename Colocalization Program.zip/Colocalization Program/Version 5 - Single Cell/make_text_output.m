function[]=make_text_output(main_mat,et_gr,clust_gr,et_red,clust_red,ni,nf,path_for_save_tmp,g_or_r_first)


%definition of inputs
% main_mat(:,1) = colocalization percentage based on area
% main_mat(:,2) = area of green cluster that colocalizes
% main_mat(:,3) = number of green cluster that colocalizes
% main_mat(:,4) = number of red cluster that colocalizes

%et_gr = path and file stem for eroded thresholded green images
%clust_gr = path and file stem for cluster images for green channel
%et_red = path and file stem for eroded thresholded red images
%clust_red = path and file stem for cluster images for red channel
%ni = starting image index
%nf = ending image index
%path_for_save = path to save text file that is outputted
%g_or_r_first = flag only needed to designate filename

main_mat

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%making giant list of coordinates, clusters and intensities%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%to speed up the code%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%counter
count_p=1;

for u=ni:nf
    
   %reading in the cluster image
   green_clu=imread(strcat(clust_gr,num2str(u),'.tif'));green_clu=double(green_clu);
   red_clu=imread(strcat(clust_red,num2str(u),'.tif'));red_clu=double(red_clu);

   %reading in the intensity image
   green_int=imread(strcat(et_gr,num2str(u),'.tif')); green_int=double(green_int); 
   red_int=imread(strcat(et_red,num2str(u),'.tif')); red_int=double(red_int);
   
   %non-zero indices
   idx_g1=find(green_clu>0);
   idx_r1=find(red_clu>0);
   
   if count_p==1
      
       %green
       clust_gr_arr(:,1)=green_clu(idx_g1); %cluster info
       clust_gr_arr(:,2)=green_int(idx_g1); %intensity info
       
       %red 
       clust_red_arr(:,1)=red_clu(idx_r1); %cluster info
       clust_red_arr(:,2)=red_int(idx_r1); %intensity info
       
       %iterate counter
       count_p=count_p+1;
       
   else
       
       %green
       clust_gr_arr_tmp=clust_gr_arr;
       clear clust_gr_arr;
       clust_gr_arr=[clust_gr_arr_tmp;[green_clu(idx_g1),green_int(idx_g1)]];
       clear clust_gr_arr_tmp;
       
       %red 
       clust_red_arr_tmp=clust_red_arr;
       clear clust_red_arr;
       clust_red_arr=[clust_red_arr_tmp;[red_clu(idx_r1),red_int(idx_r1)]];
       clear clust_red_arr_tmp;
       
   end
   
   %clear statements
   clear green_clu; clear red_clu; clear green_int; clear red_int;
   clear idx_g1; clear idx_r1;
   
end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%Making the text file%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%definition of inputs
% main_mat(:,1) = colocalization percentage based on area
% main_mat(:,2) = area of green cluster that colocalizes
% main_mat(:,3) = number of green cluster that colocalizes
% main_mat(:,4) = number of red cluster that colocalizes

%making an edit in the directory to save the text files
idx_yan=find(path_for_save_tmp=='\');
path_for_save_tmp
path_for_save=path_for_save_tmp(1:idx_yan(numel(idx_yan)-1))

%opening a text file
if g_or_r_first ==1
    
    %text file
    fileID_tay = fopen(strcat(path_for_save,'Green_first_colocalization_information.txt'),'w');
    fprintf(fileID_tay,'%12s\t %12s\t %12s\t %12s\t %12s\t %12s\t %12s\n','Green Cluster #','% Coloc','Area of Green Cluster','Integr. Int Green Cluster','Red Cluster #','Area of Red Cluster','Integr. Intensity of Red Cluster'); 

else
    
    %text file
    fileID_tay = fopen(strcat(path_for_save,'Red_first_colocalization_information.txt'),'w');
    fprintf(fileID_tay,'%12s\t %12s\t %12s\t %12s\t %12s\t %12s\t %12s\n','Red Cluster #','% Coloc','Area of Red Cluster','Integr. Int Red Cluster','Green Cluster #','Area of Green Cluster','Integr. Intensity of Green Cluster'); 

end
    
    
for f=min(main_mat(:,3)):max(main_mat(:,3))
   
    %getting a cluster that colocalizes
    idx_now=find(main_mat(:,3)==f);
    
    if numel(idx_now)>0
        
            for p=1:numel(idx_now)
               
                %percentage of colocalization
                per_coloc=main_mat(idx_now(p),1);
                
                %area and integrated intensity of green cluster
                [area_gr_cl,integr_intens_gr_cl]=get_area_integ_int(f,clust_gr_arr);
                
                %red cluster of interest
                main_mat
                red_cl_num=main_mat(idx_now(p),4)
                john=idx_now
                f
                
                %area and integrated intensity of red cluster
                [area_red_cl,integr_intens_red_cl]=get_area_integ_int(red_cl_num,clust_red_arr);
                
                %saving in text file
                fprintf(fileID_tay,'%12.8f\t %12.8f\t %12.8f\t %12.8f\t %12.8f\t %12.8f\t %12.8f\n',f,per_coloc,area_gr_cl,integr_intens_gr_cl,red_cl_num,area_red_cl,integr_intens_red_cl);
                
                %clear statements
                clear per_coloc; clear area_gr_cl; clear integr_intens_gr_cl; 
                clear red_cl_num; clear integr_intens_red_cl; clear area_red_cl;
                
            end
            
    end
    
    %clear statements
    clear idx_now;
    
    
end

%closing file for writing
fclose(fileID_tay);










