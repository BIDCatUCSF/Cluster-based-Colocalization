clear all; close all;

%paths to images - clustered images - all that matters now
% pg='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Test Data\Set 4a Images\Thresh 1a\WholeImageStackClustering\Intensity Stack\Im';
% pr='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Test Data\Set 4a Images\Thresh 3a\WholeImageStackClustering\Intensity Stack\Im';
% pge='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Test Data\Set 4a Images\Thresh 1\Im';
% pre='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Test Data\Set 4a Images\Thresh 3\Im';
% pget='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Test Data\Set 4a Images\Thresh 1a\Im';
% pret='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Test Data\Set 4a Images\Thresh 3a\Im';

%cluster images
pg='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Random Data\488nm\WholeImageStackClustering\Intensity Stack\Im';
pr='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Random Data\642nm\WholeImageStackClustering\Intensity Stack\Im';

%eroded boundary images
pge='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Random Data\488nm\ErodedBoundaryImages\MaskBoundErode';
pre='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Random Data\642nm\ErodedBoundaryImages\MaskBoundErode';

%eroded and thresholded boundary images
pget='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Random Data\488nm\ErodedThreshIms\ErodedThresh';
pret='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Random Data\642nm\ErodedThreshIms\ErodedThresh';

%path for saving
%path_save='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Misc Code\SA based colocalization\manually comparing calculation\first big ims\im';

%locating naming and finding a path for saving the images
idx_save_gr_tmp=find(pge=='\');
idx_save_gr=idx_save_gr_tmp(numel(idx_save_gr_tmp)-1);

idx_save_red_tmp=find(pre=='\');
idx_save_red=idx_save_red_tmp(numel(idx_save_red_tmp)-1);

path_green_save_tmp=pge(1:(idx_save_gr))
path_green_save1=strcat(path_green_save_tmp,'ColocalizationImages\PixelWiseColoc_Criteria1\Green\');
path_green_save2=strcat(path_green_save_tmp,'ColocalizationImages\PixelWiseColoc_Criteria2\Green\');

path_red_save_tmp=pre(1:(idx_save_red))
path_red_save1=strcat(path_red_save_tmp,'ColocalizationImages\PixelWiseColoc_Criteria1\Red\');
path_red_save2=strcat(path_red_save_tmp,'ColocalizationImages\PixelWiseColoc_Criteria2\Red\');

%making the directories
mkdir(path_green_save1);
mkdir(path_green_save2);
mkdir(path_red_save1);
mkdir(path_red_save2);


%indices of images
% num_start=9;
% num_end=110;

%indices of images
num_start=49;
num_end=91;

%counter
countg=1;
countr=1;
count_extrema=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%Load all of the clusters%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=num_start:num_end
   
    %reading in the cluster images
    im_g=imread(strcat(pg,num2str(i),'.tif')); im_g=double(im_g);
    im_r=imread(strcat(pr,num2str(i),'.tif')); im_r=double(im_r);
    
    %reading in the eroded thresholded images
    im_g_et=imread(strcat(pget,num2str(i),'.tif')); im_g_et=double(im_g_et);
    im_r_et=imread(strcat(pret,num2str(i),'.tif')); im_r_et=double(im_r_et);
    
    %finding all clusters
    idx_g_cl=find(im_g>0);
    idx_r_cl=find(im_r>0);
    
    %holding the dimension and some pre-allocation
    if i==num_start
        
        %dimension
        dim_hold=size(im_g);
        
        %pre-allocating cluster stacks
        gr_clust_stack=zeros(dim_hold(1),dim_hold(2),num_end-num_start+1);
        gr_clust_stack=double(gr_clust_stack);
        red_clust_stack=gr_clust_stack;
        
        %pre-allocating - eroded thresholded stack
        gr_erode_thresh_stack=gr_clust_stack;
        red_erode_thresh_stack=gr_clust_stack;
        
    end
    
    %extrema intensities for scaling later
    min_gr_et_arr(count_extrema,1)=min(im_g_et(1:(dim_hold(1)*dim_hold(2))));
    max_gr_et_arr(count_extrema,1)=max(im_g_et(1:(dim_hold(1)*dim_hold(2))));
    min_red_et_arr(count_extrema,1)=min(im_r_et(1:(dim_hold(1)*dim_hold(2))));
    max_red_et_arr(count_extrema,1)=max(im_r_et(1:(dim_hold(1)*dim_hold(2))));
    count_extrema=count_extrema+1;
    
    %storing the eroded thresholded images
    gr_erode_thresh_stack(:,:,i-num_start+1)=im_g_et;
    red_erode_thresh_stack(:,:,i-num_start+1)=im_r_et;
    clear im_g_et; clear im_r_et;
    
    %holding onto the images with cluster information
    gr_clust_stack(:,:,i-num_start+1)=im_g;
    red_clust_stack(:,:,i-num_start+1)=im_r;
    
    if numel(idx_g_cl)>0 && countg==1
        
        %converting to xy coordinates
        [yg,xg]=ind2sub(size(im_g),idx_g_cl);
        
        %store clusters
        all_gr_cl(:,1)=xg;
        all_gr_cl(:,2)=yg;
        all_gr_cl(:,3)=linspace(i,i,numel(xg))';
        all_gr_cl(:,4)=im_g(idx_g_cl);
        
        %iterate counter
        countg=countg+1;
        
    end
    
    if numel(idx_g_cl)>0 && countg>1
        
        %converting to xy coordinates
        [yg,xg]=ind2sub(size(im_g),idx_g_cl);
        
        %store clusters
        all_gr_cl_tmp=all_gr_cl;
        clear all_gr_cl;
        all_gr_cl=[all_gr_cl_tmp;[xg,yg,linspace(i,i,numel(xg))',im_g(idx_g_cl)]];
        clear all_gr_cl_tmp;
        
    end
    
    if numel(idx_r_cl)>0 && countr==1
       
        %converting to coordinates
        [yr,xr]=ind2sub(size(im_r),idx_r_cl);
        
        %store clusters
        all_red_cl(:,1)=xr;
        all_red_cl(:,2)=yr;
        all_red_cl(:,3)=linspace(i,i,numel(xr))';
        all_red_cl(:,4)=im_r(idx_r_cl);
        
        %iterate counter
        countr=countr+1;
        
    end
    
    if numel(idx_r_cl)>0 && countr>1
        
       %converting to coordinates
       [yr,xr]=ind2sub(size(im_r),idx_r_cl);
        
       %storing
       all_red_cl_tmp=all_red_cl;
       clear all_red_cl;
       all_red_cl=[all_red_cl_tmp;[xr,yr,linspace(i,i,numel(xr))',im_r(idx_r_cl)]];
       clear all_red_cl_tmp;
       
       
    end
    
    
     %clear statements
    clear im_g; clear im_r; clear idx_g_cl; clear idx_r_cl;
    clear xg; clear yg; clear xr; clear yr;
    
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%Colocalization calculation%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%colocalization - green first
[green_coloc_per_for_hist1,gr_thresh_bin_stack1,gr_thresh_bin_stack1_perc,gr_thresh_bin_stack1_imaris]=does_it_coloc_v2(all_gr_cl,all_red_cl,num_start,num_end,dim_hold,1);
[green_coloc_per_for_hist2,gr_thresh_bin_stack2,gr_thresh_bin_stack2_perc,gr_thresh_bin_stack2_imaris]=does_it_coloc_v2(all_gr_cl,all_red_cl,num_start,num_end,dim_hold,2);

%colocalization - red frist
[red_coloc_per_for_hist1,red_thresh_bin_stack1,red_thresh_bin_stack1_perc,red_thresh_bin_stack1_imaris]=does_it_coloc_v2(all_red_cl,all_gr_cl,num_start,num_end,dim_hold,1);
[red_coloc_per_for_hist2,red_thresh_bin_stack2,red_thresh_bin_stack2_perc,red_thresh_bin_stack2_imaris]=does_it_coloc_v2(all_red_cl,all_gr_cl,num_start,num_end,dim_hold,2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%Histograms that will ultimately be saved%%%%%%%%%%%%%%%%%%%

%final histograms and plots
make_the_histogram(green_coloc_per_for_hist1,'Green First - Overlapping',path_green_save1);
make_the_histogram(green_coloc_per_for_hist2,'Green First - Within 1 Pixel',path_green_save2);

make_the_histogram(red_coloc_per_for_hist1,'Red First - Overlapping',path_red_save1);
make_the_histogram(red_coloc_per_for_hist2,'Red First - Within 1 Pixel',path_red_save2);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%the RGB rendering%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%intensities maxima and minima
abs_min_gr=min(min_gr_et_arr(:,1));
abs_max_gr=max(max_gr_et_arr(:,1));
abs_min_red=min(min_red_et_arr(:,1));
abs_max_red=max(max_red_et_arr(:,1));

%extrema of clusters
min_g_cl_num=min(all_gr_cl(:,4));
max_g_cl_num=max(all_gr_cl(:,4));
min_r_cl_num=min(all_red_cl(:,4));
max_r_cl_num=max(all_red_cl(:,4));

%eroded threshed images
%gr_erode_thresh_stack
%red_erode_thresh_stack

%cluster images
%gr_clust_stack
%red_clust_stack

%threshold binary masks 
%gr_thresh_bin_stack1
%gr_thresh_bin_stack2
%red_thresh_bin_stack1
%red_thresh_bin_stack2

%thresholded percentages
%gr_thresh_bin_stack1_perc
%gr_thresh_bin_stack2_perc
%red_thresh_bin_stack1_perc
%red_thresh_bin_stack2_perc

for q=1:(num_end-num_start+1)
   
    %eroded thresh ims
    get_now=gr_erode_thresh_stack(:,:,q);
    ret_now=red_erode_thresh_stack(:,:,q);
    
    %cluster images
    gc_now=gr_clust_stack(:,:,q);
    rc_now=red_clust_stack(:,:,q);
    
    %colocalization percentage images
    g_p_t1=gr_thresh_bin_stack1_perc(:,:,q);
    r_p_t1=red_thresh_bin_stack1_perc(:,:,q);
    g_p_t2=gr_thresh_bin_stack2_perc(:,:,q);
    r_p_t2=red_thresh_bin_stack2_perc(:,:,q);
    
    %binary threshold images
    g_t1=gr_thresh_bin_stack1(:,:,q);
    r_t1=red_thresh_bin_stack1(:,:,q);
    g_t2=gr_thresh_bin_stack2(:,:,q);
    r_t2=red_thresh_bin_stack2(:,:,q);
    

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%RGB Rendering%%%%%%%%%%%
    
    %eroded thresh ims
    get_now_rgb=make_rgb_blank(get_now,abs_max_gr,1);
    ret_now_rgb=make_rgb_blank(ret_now,abs_max_red,2);
    
    %composite rgb
    comp_now_rgb=get_now_rgb+ret_now_rgb;
    
    %cluster images
    gc_now_rgb=make_rgb_blank(gc_now,max_g_cl_num,3);
    rc_now_rgb=make_rgb_blank(rc_now,max_r_cl_num,3);
    
    %colocalization percentage images
    g_p_t1_rgb=make_rgb_blank(g_p_t1,100,3);
    r_p_t1_rgb=make_rgb_blank(r_p_t1,100,3);
    g_p_t2_rgb=make_rgb_blank(g_p_t2,100,3);
    r_p_t2_rgb=make_rgb_blank(r_p_t2,100,3);
    
    %binary threshold images
    g_t1_rgb_tmp=make_rgb_blank(g_t1,1,4);
    r_t1_rgb_tmp=make_rgb_blank(r_t1,1,4);
    g_t2_rgb_tmp=make_rgb_blank(g_t2,1,4);
    r_t2_rgb_tmp=make_rgb_blank(r_t2,1,4);
    
    
    
    %masking for the rendering
    g_t1_rgb(:,:,1)=g_t1_rgb_tmp(:,:,1).*comp_now_rgb(:,:,1);
    g_t1_rgb(:,:,2)=g_t1_rgb_tmp(:,:,2).*comp_now_rgb(:,:,2);
    g_t1_rgb(:,:,3)=g_t1_rgb_tmp(:,:,3).*comp_now_rgb(:,:,3);
    
    r_t1_rgb(:,:,1)=r_t1_rgb_tmp(:,:,1).*comp_now_rgb(:,:,1);
    r_t1_rgb(:,:,2)=r_t1_rgb_tmp(:,:,2).*comp_now_rgb(:,:,2);
    r_t1_rgb(:,:,3)=r_t1_rgb_tmp(:,:,3).*comp_now_rgb(:,:,3);
    
    g_t2_rgb(:,:,1)=g_t2_rgb_tmp(:,:,1).*comp_now_rgb(:,:,1);
    g_t2_rgb(:,:,2)=g_t2_rgb_tmp(:,:,2).*comp_now_rgb(:,:,2);
    g_t2_rgb(:,:,3)=g_t2_rgb_tmp(:,:,3).*comp_now_rgb(:,:,3);
    
    r_t2_rgb(:,:,1)=r_t2_rgb_tmp(:,:,1).*comp_now_rgb(:,:,1);
    r_t2_rgb(:,:,2)=r_t2_rgb_tmp(:,:,2).*comp_now_rgb(:,:,2);
    r_t2_rgb(:,:,3)=r_t2_rgb_tmp(:,:,3).*comp_now_rgb(:,:,3);
    
    %making the giant images
    big_im_g1=[comp_now_rgb,g_t1_rgb,g_p_t1_rgb];
    big_im_g2=[comp_now_rgb,g_t2_rgb,g_p_t2_rgb];
    big_im_r1=[comp_now_rgb,r_t1_rgb,r_p_t1_rgb];
    big_im_r2=[comp_now_rgb,r_t2_rgb,r_p_t2_rgb];
    
    
    %saving
    imwrite(big_im_g1,strcat(path_green_save1,num2str(num_start+q-1),'.png'));
    imwrite(big_im_g2,strcat(path_green_save2,num2str(num_start+q-1),'.png'));
    imwrite(big_im_r1,strcat(path_red_save1,num2str(num_start+q-1),'.png'));
    imwrite(big_im_r2,strcat(path_red_save2,num2str(num_start+q-1),'.png'));

    
    %clear statements
    clear get_now; clear ret_now; clear gc_now; clear rc_now;
    clear g_p_t1; clear r_p_t1; clear g_p_t2; clear r_p_t2;
    clear g_t1; clear r_t1; clear g_t2; clear r_t2;
    clear get_now_rgb; clear ret_now_rgb; 
    clear comp_now_rgb;
    clear gc_now_rgb; clear rc_now_rgb; clear g_p_t1_rgb;
    clear r_p_t1_rgb; clear clear g_p_t2_rgb; clear r_p_t2_rgb;
    clear g_t1_rgb_tmp; clear r_t1_rgb_tmp; clear g_t2_rgb_tmp;
    clear r_t2_rgb_tmp;
    clear g_t1_rgb; clear r_t1_rgb; clear g_t2_rgb; clear r_t2_rgb; 
    clear big_im_g1; clear big_im_g2; clear big_im_r1; clear big_im_r2;


end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%This is the final rendering that I have added%%%%%%%%%%%%%%%%
%It is supposed to show what is left before and after clustering-based%%%%%
%%%%%%%%%%%%%%%%%%%%%%colocalization%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% path_green_save1=strcat(path_green_save_tmp,'ColocalizationImages\PixelWiseColoc_Criteria1\Green\');
% path_green_save2=strcat(path_green_save_tmp,'ColocalizationImages\PixelWiseColoc_Criteria2\Green\');

for s=1:(num_end-num_start+1)
    
    %eroded thresh ims
    get_now=gr_erode_thresh_stack(:,:,s);
    ret_now=red_erode_thresh_stack(:,:,s);

    %binary threshold images
    g_t1=gr_thresh_bin_stack1(:,:,s);
    r_t1=red_thresh_bin_stack1(:,:,s);
    g_t2=gr_thresh_bin_stack2(:,:,s);
    r_t2=red_thresh_bin_stack2(:,:,s);
    
    %cluster images
    get_cl=gr_clust_stack(:,:,s);
    ret_cl=red_clust_stack(:,:,s);
    
    %inverted masks
    gi_t1=invert_mask(get_cl,g_t1);
    ri_t1=invert_mask(ret_cl,r_t1);
    gi_t2=invert_mask(get_cl,g_t2);
    ri_t2=invert_mask(ret_cl,r_t2);

    %image stack for surface
    ch1_cr1_for_surface=[get_now,get_now.*g_t1,get_now.*gi_t1];
    ch2_cr1_for_surface=[ret_now,ret_now.*r_t1,ret_now.*ri_t1];
    ch1_cr2_for_surface=[get_now,get_now.*g_t2,get_now.*gi_t2];
    ch2_cr2_for_surface=[ret_now,ret_now.*r_t2,ret_now.*ri_t2];  

    %making directories
    if s==1
        
        %new directories
        path_green_save1a_1=strcat(path_green_save1,'ClusterDifference\Intensity\Ch1\');
        path_green_save1a_2=strcat(path_green_save1,'ClusterDifference\Intensity\Ch2\');
    	path_green_save1b=strcat(path_green_save1,'ClusterDifference\RGB\');
        
        path_green_save2a_1=strcat(path_green_save2,'ClusterDifference\Intensity\Ch1\');
        path_green_save2a_2=strcat(path_green_save2,'ClusterDifference\Intensity\Ch2\');
    	path_green_save2b=strcat(path_green_save2,'ClusterDifference\RGB\');
        
        %creating directories 
        mkdir(path_green_save1a_1);
        mkdir(path_green_save1a_2);
        mkdir(path_green_save1b);
        
        mkdir(path_green_save2a_1);
        mkdir(path_green_save2a_2)        
        mkdir(path_green_save2b);
        
    end
        
    %saving
    imwrite(uint16(ch1_cr1_for_surface),strcat(path_green_save1a_1,'Ch1Cr1Stack',num2str(num_start+s-1),'.tif'));
    imwrite(uint16(ch2_cr1_for_surface),strcat(path_green_save1a_2,'Ch2Cr1Stack',num2str(num_start+s-1),'.tif'));
    imwrite(uint16(ch1_cr2_for_surface),strcat(path_green_save2a_1,'Ch1Cr1Stack',num2str(num_start+s-1),'.tif'));
    imwrite(uint16(ch2_cr2_for_surface),strcat(path_green_save2a_2,'Ch2Cr1Stack',num2str(num_start+s-1),'.tif'));
    
    %rgb rendering
    get_now_rgb=make_rgb_blank(get_now,abs_max_gr,1);
    ret_now_rgb=make_rgb_blank(ret_now,abs_max_red,2);
    
    %binary threshold images
    t1_rgb_tmp=make_rgb_blank(g_t1+r_t1,1,4);
    t2_rgb_tmp=make_rgb_blank(g_t2+r_t2,1,4);
    
    %iverted binary thresholded images
    i_t1_rgb_tmp=make_rgb_blank(gi_t1+ri_t1,1,4);
    i_t2_rgb_tmp=make_rgb_blank(gi_t2+ri_t2,1,4);
    
    %masking
    t1_rgb=mask_rgb_images(get_now_rgb+ret_now_rgb,t1_rgb_tmp);   
    t2_rgb=mask_rgb_images(get_now_rgb+ret_now_rgb,t2_rgb_tmp); 

    i_t1_rgb=mask_rgb_images(get_now_rgb++ret_now_rgb,i_t1_rgb_tmp);    
    i_t2_rgb=mask_rgb_images(get_now_rgb++ret_now_rgb,i_t2_rgb_tmp);
 
    
    %saving
    cr1_surface_rgb=[get_now_rgb+ret_now_rgb,t1_rgb,i_t1_rgb];
    cr2_surface_rgb=[get_now_rgb+ret_now_rgb,t2_rgb,i_t2_rgb];
    imwrite(cr1_surface_rgb,strcat(path_green_save1b,'Im',num2str(num_start+s-1),'.png'));
    imwrite(cr2_surface_rgb,strcat(path_green_save2b,'Im',num2str(num_start+s-1),'.png'));
    
    %clear statements
    clear cr1_surface_rgb; clear cr2_surface_rgb;
    clear get_now; clear ret_now;
    clear g_t1; clear r_t1; clear g_t2; clear r_t2;
    clear get_cl; clear ret_cl; clear gi_t1; clear ri_t1; clear gi_t2; clear ri_t2;
    clear ch1_cr1_for_surface;
    clear ch2_cr1_for_surface;
    clear ch1_cr2_for_surface;
    clear ch2_cr2_for_surface;
    clear get_now_rgb; clear ret_now_rgb;
    clear t1_rgb_tmp;
    clear t2_rgb_tmp;
    clear i_t1_rgb_tmp;
    clear i_t2_rgb_tmp;
    clear g_t1_rgb; clear r_t1_rgb;
    clear g_t2_rgb; clear r_t2_rgb;
    clear gi_t1_rgb; clear ri_t1_rgb;
    clear gi_t2_rgb; clear ri_t2_rgb;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%making a text file as output%%%%%%%%%%%%%%%%%%%%%%%%%%%

%image indices
%num_start
%num_end

%paths to save images
% path_green_save1=strcat(path_green_save_tmp,'ColocalizationImages\PixelWiseColoc_Criteria1\Green\');
% path_green_save2=strcat(path_green_save_tmp,'ColocalizationImages\PixelWiseColoc_Criteria2\Green\');
% 
% path_red_save1=strcat(path_red_save_tmp,'ColocalizationImages\PixelWiseColoc_Criteria1\Red\');
% path_red_save2=strcat(path_red_save_tmp,'ColocalizationImages\PixelWiseColoc_Criteria2\Red\');

%paths to read images
% %cluster images
% pg='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Random Data\488nm\WholeImageStackClustering\Intensity Stack\Im';
% pr='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Random Data\642nm\WholeImageStackClustering\Intensity Stack\Im';
% 
% %eroded and thresholded boundary images
% pget='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Random Data\488nm\ErodedThreshIms\ErodedThresh';
% pret='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Random Data\642nm\ErodedThreshIms\ErodedThresh';

%other matrices that need to passed to the program
% green_coloc_per_for_hist1
% green_coloc_per_for_hist2
% red_coloc_per_for_hist1
% red_coloc_per_for_hist2


%call to function
%make_text_output(main_mat,et_gr,clust_gr,et_red,clust_red,ni,nf,path_for_save,g_or_r_first)

%green first criteria 1
make_text_output(green_coloc_per_for_hist1,pget,pg,pret,pr,num_start,num_end,path_green_save1,1);

%green first criteria 2
make_text_output(green_coloc_per_for_hist2,pget,pg,pret,pr,num_start,num_end,path_green_save2,1);

%red first criteria 1
make_text_output(red_coloc_per_for_hist1,pret,pr,pget,pg,num_start,num_end,path_red_save1,2);

%red first criteria 2
make_text_output(red_coloc_per_for_hist2,pret,pr,pget,pg,num_start,num_end,path_red_save2,2);




















