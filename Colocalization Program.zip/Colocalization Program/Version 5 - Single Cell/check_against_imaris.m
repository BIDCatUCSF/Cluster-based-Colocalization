clear all; close all;

%This is a code written to check my calculations of colocalization against
%that which Imaris did for the same data

num_start=49;
num_end=91;

%path to John's pixelwise colocalization calculation
path_john='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Random Data\488nm\ColocalizationImages\PixelWiseColoc_Criteria1\Green\Imaris\ImarisCrit1Im';


%path to Imaris' calculation of pixel-wise colocalization
path_imaris='C:\Users\jeichorst\Desktop\en project\Oct2018 Images\Colocalization Software\Random Data\Imaris\ch2\ImarisColoc_C2_Z';

%counter
count=0;

for i=num_start:num_end
   
    %John Calc
    im_john=imread(strcat(path_john,num2str(i),'.tif'));
    
    %imaris calc
    if count<10
        im_imaris=imread(strcat(path_imaris,'00',num2str(count),'.tif'));
    else
        im_imaris=imread(strcat(path_imaris,'0',num2str(count),'.tif'));
    end
    
    %rgb rendering
    im_john_rgb=make_rgb_blank(im_john,1,1);
    im_imaris_rgb=make_rgb_blank(im_imaris,1,2);
    figure, imshow([im_john_rgb,im_imaris_rgb,im_john_rgb+im_imaris_rgb]);
    
    %iterate counter
    count=count+1;
    
    %clear statements
    clear im_john; clear im_imaris;
    clear im_john_rgb; clear im_imaris_rgb;
end
















