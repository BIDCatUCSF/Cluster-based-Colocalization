function[area_ret,intens_ret]=get_area_integ_int(c_num,big_arr)

%definition of inputs
%c_num = number of cluster of interest
%big_arr(:,1) = all cluster numbers from image stack
%big_arr(:,2) = pixel-wise intensities from entire image stack

%definition of outputs
%area_ret = area (in pixel) of cluster of interest
%intens_ret = integrated intensity of cluster of interest


%calculating area and intensities
c_num
idx_area=find(big_arr(:,1)==c_num);

if numel(idx_area)>0
   
    %things to return
    area_ret=numel(idx_area);
    intens_ret=sum(big_arr(idx_area,2));
    
else
    
    %thing to return
    area_ret=0;
    intens_ret=0;
    
end










