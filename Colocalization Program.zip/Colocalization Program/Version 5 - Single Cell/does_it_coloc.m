function[thing_ret,stack_ret,stack_ret_perc]=does_it_coloc(big_g,big_r,ns,ne,the_dim,criteria_decide)


%counter
count_ret=1;

%allocating for return
big_g_ret=big_g;

%extrema of cluster
min_g_cl=min(big_g(:,4));
max_g_cl=max(big_g(:,4));


for j=min_g_cl:max_g_cl
    
   %get a current green cluster
   green_cl_idx=find(big_g(:,4)==j);
   
   if numel(green_cl_idx)>0
       
       %xyz coordinates of green cluster
       the_gr(:,1)=big_g(green_cl_idx,1);%x
       the_gr(:,2)=big_g(green_cl_idx,2);%y
       the_gr(:,3)=big_g(green_cl_idx,3);%z
       
       %counter
       count_dist=0;
       
       %distance calculation
       for k=1:numel(green_cl_idx)
          
           %distance
           dist_arr(:,1)=(((the_gr(k,1)-big_r(:,1)).^2)+((the_gr(k,2)-big_r(:,2)).^2)+((the_gr(k,3)-big_r(:,3)).^2)).^0.5;
           
           %too close
           if criteria_decide==1
             idx_too_close=find(dist_arr(:,1)<1);
           elseif criteria_decide==2
            idx_too_close=find(dist_arr(:,1)<=1);
           end
           if numel(idx_too_close)>0
               count_dist=count_dist+1;
           end
           
           count_dist
           
           %clear statment
           clear dist_arr; clear idx_too_close;
           
       end
       
       
       %clear statments
       clear the_gr; 
       
       %storing
       
       if count_dist>0
           
           %returning the percentage of colocalization for the histogram
           thing_ret(count_ret,1)=(count_dist/numel(green_cl_idx)).*100;
           thing_ret(count_ret,2)=numel(green_cl_idx);
           count_ret=count_ret+1;
           
           %adding a column to the input matrix for percentage of
           %colocalization
           big_g_ret(green_cl_idx,5)=linspace(((count_dist/numel(green_cl_idx)).*100),((count_dist/numel(green_cl_idx)).*100),numel(green_cl_idx))';
           
       end
   end

       
   %clear statments
   clear green_cl_idx; 
    
end


count_ret

min_g_cl=min(big_g(:,4))
max_g_cl=max(big_g(:,4))


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%Creating a binary image stack%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%counter
count_zero=1

%total number of images
tot_ims=ne-ns+1;

%stack of images to return 
stack_ret=zeros(the_dim(1),the_dim(2),tot_ims); stack_ret=double(stack_ret);
stack_ret_perc=stack_ret;

for r=ns:ne
   
    %looking for z
    is_z=find(big_g_ret(:,3)==r);
    
    if numel(is_z)>0
        
        %blank image
        the_blank=zeros(the_dim(1),the_dim(2));
        the_blank=double(the_blank);
        
        %blank image for percemt
        blank_im_perc=the_blank;
        
        %some thresholding to be implemented later
        xk=big_g_ret(is_z,1);
        yk=big_g_ret(is_z,2);
        perc_k=big_g_ret(is_z,5);
        idx_pt=find(perc_k>1);
        
        if numel(idx_pt)>0
            
            %loading up the binary image
            [idx_bin]=sub2ind(size(the_blank),yk(idx_pt),xk(idx_pt));
            the_blank(idx_bin)=1;
            
            %loading the percent image
            blank_im_perc(idx_bin)=perc_k(idx_pt);
            
            %something curious about
            idx_is_zero=find(perc_k<1);
            
            if count_zero==1
                all_zero=idx_is_zero;
                count_zero=count_zero+1;
            else
                all_zero_tmp=all_zero;
                clear all_zero;
                all_zero=[all_zero_tmp;idx_is_zero];
                clear all_zero_tmp;
            end
                
            %clear statements
            clear idx_bin; clear idx_is_zero;
        end
        
        %adding to the stack
        stack_ret(:,:,r-ns+1)=the_blank;
        stack_ret_perc(:,:,r-ns+1)=blank_im_perc;
        
        %some clear statement
        clear the_blank; clear xk; clear yk; clear perc_k; clear idx_pt;
        clear blank_im_perc;
        
    end
    
    %clear statments
    clear is_z;
    
    
end


this_is_zero=all_zero











