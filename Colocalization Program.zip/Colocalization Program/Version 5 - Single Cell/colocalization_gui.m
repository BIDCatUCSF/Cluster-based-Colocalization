function varargout = colocalization_gui(varargin)
% COLOCALIZATION_GUI MATLAB code for colocalization_gui.fig
%      COLOCALIZATION_GUI, by itself, creates a new COLOCALIZATION_GUI or raises the existing
%      singleton*.
%
%      H = COLOCALIZATION_GUI returns the handle to a new COLOCALIZATION_GUI or the handle to
%      the existing singleton*.
%
%      COLOCALIZATION_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in COLOCALIZATION_GUI.M with the given input arguments.
%
%      COLOCALIZATION_GUI('Property','Value',...) creates a new COLOCALIZATION_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before colocalization_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to colocalization_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help colocalization_gui

% Last Modified by GUIDE v2.5 15-Feb-2019 14:07:51

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @colocalization_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @colocalization_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before colocalization_gui is made visible.
function colocalization_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to colocalization_gui (see VARARGIN)

% Choose default command line output for colocalization_gui
% a_map=[[0,0,0];[1,1,1]];
% axes(handles.axes1);
% imagesc(0);colormap(a_map);

%intializing radio button
handles.OverlapYesNo=0;
handles.OnePixelYesNo=0;

handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes colocalization_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = colocalization_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%button for 488nm images
[file_488,path_488,success]=uigetfile;
handles.filename_488=file_488;
handles.pathname_488=path_488;

guidata(hObject, handles);

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%button for 642nm images
[file_642,path_642,success]=uigetfile;
handles.filename_642=file_642;
handles.pathname_642=path_642;

guidata(hObject, handles);

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Go Button

%green images
file_488_send=handles.filename_488;
path_488_send_tmp=handles.pathname_488;

%red images
file_642_send=handles.filename_642;
path_642_send_tmp=handles.pathname_642;

%getting the stems of the path - green channel
idx_g=find(path_488_send_tmp=='\');
path_488_send=path_488_send_tmp(1:(idx_g(numel(idx_g)-1)))

%getting the stems of the
idx_r=find(path_642_send_tmp=='\');
path_642_send=path_642_send_tmp(1:(idx_r(numel(idx_r)-1)))

%getting the number of images
a=dir([path_488_send_tmp,'*.tif']);
num_ims=numel(a);

%getting the starting and ending image numbers
file_488_send
idx_per=find(file_488_send=='.')
num_start_tmp=file_488_send(idx_per(1)-2:idx_per(1)-1);
num_start1=str2num(num_start_tmp);

%if the image index starts below 10
if numel(num_start1)<1
   
    %clear statements
    clear num_start_tmp; clear num_start;
    
    %initial image index
    num_start_tmp=file_488_send(idx_per(1)-1)
    num_start1=str2num(num_start_tmp)
    
end

%final index
num_end1=num_start1+num_ims-1;

%putting these indices into handles
handles.numstart=num_start1;
handles.numend=num_end1;

%for rendering purposes I am holding onto this directory
handles.TopDirectory=path_488_send;
handles.TopDirectoryRed=path_642_send;

%function call
[composite_max_projection_rgb,gr_thresh_bin_stack1_perc1,gr_thresh_bin_stack2_perc1,red_thresh_bin_stack1_perc1,red_thresh_bin_stack2_perc1,abs_max_gr1,abs_max_red1,gc_now1,rc_now1]=manual_compare_exe_func_v2(path_488_send,file_488_send,path_642_send,file_642_send,num_start1,num_end1);

%making the figure a little bigger
composite_max_projection_rgb_use=imresize(composite_max_projection_rgb,2);

%adding figure;
axes(handles.axes1);
imshow(composite_max_projection_rgb_use);

%storing image stacks into handles so that I can use them later
handles.GreenFirstColocPerc1=gr_thresh_bin_stack1_perc1;
handles.GreenFirstColocPerc2=gr_thresh_bin_stack2_perc1;
handles.RedFirstColocPerc1=red_thresh_bin_stack1_perc1;
handles.RedFirstColocPerc2=red_thresh_bin_stack2_perc1;
handles.GreenMax=abs_max_gr1;
handles.RedMax=abs_max_red1;
handles.GreenEtImages=gc_now1;
handles.RedEtImages=rc_now1;


guidata(hObject, handles);

% Hint: get(hObject,'Value') returns toggle state of radiobutton1


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%link to Imaris button

%initialization
aImarisApplication=[];

%counter
count1=1;

%declaring ID
ids_to_try=[0,1,2,3,4,5,6,7,8,9,10];

while numel(aImarisApplication)==0 && count1<11
    
    aImarisApplicationID=ids_to_try(count1);
    count1=count1+1;
    
    
    % get the application object
    if isa(aImarisApplicationID, 'Imaris.IApplicationPrxHelper')
        % called from workspace
        aImarisApplication = aImarisApplicationID;
    else
        % connect to Imaris interface
        javaaddpath ImarisLib.jar
        vImarisLib = ImarisLib;
        %   vObjectId = StartImarisInstance;
        if ischar(aImarisApplicationID)
            aImarisApplicationID = round(str2double(aImarisApplicationID));
        end
        aImarisApplication = vImarisLib.GetApplication(aImarisApplicationID);
    end

end

%imaris thing that I need to hold onto
handles.ImarisHoldIt=aImarisApplication;

you_are_connected=10

guidata(hObject, handles);


% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the overlapping button
handles.OverlapYesNo=get(hObject,'Value');

guidata(hObject, handles);
% Hint: get(hObject,'Value') returns toggle state of radiobutton4


% --- Executes on button press in radiobutton5.
function radiobutton5_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%this is the within one pixel button
handles.OnePixelYesNo=get(hObject,'Value');

guidata(hObject, handles);

% Hint: get(hObject,'Value') returns toggle state of radiobutton5


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is button to look at colocalized pixels (Imaris Copy)

%image indices
the_start=handles.numstart;
the_end=handles.numend;

%top most directory - green channel
top_green_path=handles.TopDirectory;
path_binary=strcat(top_green_path,'\ColocalizationImages\PixelWiseColoc_Criteria1\Green\Imaris\ImarisCrit1Im');

%counter
count_binary=1;

%make an image stack
for r=the_start:the_end
   
    %reading in the image
    imb=imread(strcat(path_binary,num2str(r),'.tif'));
    
    %re-casting
    imb=uint16(imb);
    
    if count_binary == 1
        
        %dimensions
        dim1=size(imb,1);
        dim2=size(imb,2);
        
        %pre-allocating for speed
        stack_b=zeros(dim1,dim2,the_end-the_start+1);
        
        %re-casting
        stack_b=uint16(stack_b);
    
    end
    
    %loading
    stack_b(:,:,count_binary)=imb;
    
    %iterate counter
    count_binary=count_binary+1;
    
    %clear statement
    clear imb;
    
end


tot_ims=the_end-the_start+1
size(stack_b)

%loading single channel image into Imaris
aImarisApplication=handles.ImarisHoldIt;
vDataSet = aImarisApplication.GetFactory.CreateDataSet;
vDataSet.Create(Imaris.tType.eTypeUInt16,dim1,dim2,tot_ims,1,1);
vDataSet.SetDataVolumeShorts(uint16(stack_b),0,0);
aImarisApplication.SetDataSet(vDataSet); 

%setting the intensity maximum for display
aImarisApplication.GetDataSet.SetChannelRange(0,0,1);

guidata(hObject, handles);



% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the % colocalization of cluster 488nm button - integer matrices

%image indices
the_start=handles.numstart;
the_end=handles.numend;

%top most directory - green channel
top_green_path=handles.TopDirectory;

%decision - overlap or within 1 pixel
dec_now=handles.OverlapYesNo;

if dec_now==1
   path_g=strcat(top_green_path,'\ColocalizationImages\PixelWiseColoc_Criteria1\Green\Percent Coloc\ImPerc'); 
else
    path_g=strcat(top_green_path,'\ColocalizationImages\PixelWiseColoc_Criteria2\Green\Percent Coloc\ImPerc');
end

%counter
count2=1;

%total number of images
tot_n_ims=the_end-the_start+1;

for j=the_start:the_end
    
    %reading in the image
    im1=imread(strcat(path_g,num2str(j),'.tif'));
    im1=uint16(im1);
    
    if count2==1
    
        %dimensions
        dim1a=size(im1,1);
        dim2a=size(im1,2);
        
        %pre-allocating
        stack_g=zeros(dim1a,dim2a,tot_n_ims);
        stack_g=uint16(stack_g);
        
    end
    
    %loading
    stack_g(:,:,count2)=im1;
    
    %iterate counter
    count2=count2+1;
    
    %clear statements
    clear im1;
    
end

%loading single channel image into Imaris
aImarisApplication=handles.ImarisHoldIt;
vDataSet = aImarisApplication.GetFactory.CreateDataSet;
vDataSet.Create(Imaris.tType.eTypeUInt16,dim1a,dim2a,tot_n_ims,1,1);
vDataSet.SetDataVolumeShorts(uint16(stack_g),0,0);
aImarisApplication.SetDataSet(vDataSet); 

%setting the intensity maximum for display
aImarisApplication.GetDataSet.SetChannelColorRGBA(0,570475008) %green
aImarisApplication.GetDataSet.SetChannelRange(0,0,100);


guidata(hObject, handles);

% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the % colocalization of cluster 642nm button - integer matrices

%image indices
the_start=handles.numstart;
the_end=handles.numend;

%top most directory - green channel
top_red_path=handles.TopDirectoryRed;

%decision - overlap or within 1 pixel
dec_now=handles.OverlapYesNo;

if dec_now==1
   path_r=strcat(top_red_path,'\ColocalizationImages\PixelWiseColoc_Criteria1\Red\Percent Coloc\ImPerc'); 
else
    path_r=strcat(top_red_path,'\ColocalizationImages\PixelWiseColoc_Criteria1\Red\Percent Coloc\ImPerc');
end

%counter
count2=1;

%total number of images
tot_n_ims=the_end-the_start+1;

for j=the_start:the_end
    
    %reading in the image
    im1=imread(strcat(path_r,num2str(j),'.tif'));
    im1=uint16(im1);
    
    if count2==1
    
        %dimensions
        dim1a=size(im1,1);
        dim2a=size(im1,2);
        
        %pre-allocating
        stack_r=zeros(dim1a,dim2a,tot_n_ims);
        stack_r=uint16(stack_r);
        
    end
    
    %loading
    stack_r(:,:,count2)=im1;
    
    %iterate counter
    count2=count2+1;
    
    %clear statements
    clear im1;
    
end

%loading single channel image into Imaris
aImarisApplication=handles.ImarisHoldIt;
vDataSet = aImarisApplication.GetFactory.CreateDataSet;
vDataSet.Create(Imaris.tType.eTypeUInt16,dim1a,dim2a,tot_n_ims,1,1);
vDataSet.SetDataVolumeShorts(uint16(stack_r),0,0);
aImarisApplication.SetDataSet(vDataSet); 

%setting the intensity maximum for display
aImarisApplication.GetDataSet.SetChannelColorRGBA(0,570622658) %red
aImarisApplication.GetDataSet.SetChannelRange(0,0,100);


guidata(hObject, handles);

% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the 3 panel which pixels are in clusters that colocalize

%image indices
the_start=handles.numstart;
the_end=handles.numend;
num_ims=the_end-the_start+1;

%decision on type of overlap
dec_over=handles.OverlapYesNo;

%threshold of colocalization percentages 
thresh_p=handles.ColocPercThresh;

%grabbing image stacks from the handles
green_perc_c1=handles.GreenFirstColocPerc1;
green_perc_c2=handles.GreenFirstColocPerc2;
red_perc_c1=handles.RedFirstColocPerc1;
red_perc_c2=handles.RedFirstColocPerc2;
high_green=handles.GreenMax;
high_red=handles.RedMax;
green_et=handles.GreenEtImages;
red_et=handles.RedEtImages;

%making the image stacks to display in Imaris

%counter
count3=1;

for r=the_start:the_end
   
    %reading in the cluster percent images
    if dec_over==1 %overlapping
        gr_perc_im=green_perc_c1(:,:,count3);
        red_perc_im=red_perc_c1(:,:,count3);
    else %within 1 pixel
        gr_perc_im=green_perc_c2(:,:,count3);
        red_perc_im=red_perc_c2(:,:,count3);
    end
    
   
    
    %reading in the eroded thresholded images
    gr_im=green_et(:,:,count3); gr_im=uint16(gr_im);
    red_im=red_et(:,:,count3); red_im=uint16(red_im);
    
    
    
    %dimensions and pre-allocating space
    if count3==1
        
        %dimensions
        dim1b=size(gr_im,1);
        dim2b=size(gr_im,2)*3;
        
        %pre-allocating 
        stackA=zeros(dim1b,dim2b,num_ims);
        stackB=zeros(dim1b,dim2b,num_ims);
        stackA=uint16(stackA);
        stackB=uint16(stackB);
        
    end
    
    
    %indices to mask and include based on threshold
    idx_gr_keep=find(gr_perc_im<=thresh_p);
    idx_gr_mask=find(gr_perc_im>thresh_p);
    idx_red_keep=find(red_perc_im<=thresh_p);
    idx_red_mask=find(red_perc_im>thresh_p);
    
    
    %masking 
    green2=gr_im; red2=red_im;
    green3=gr_im; red3=red_im;
    
    if numel(idx_gr_keep)>0
        green2(idx_gr_keep)=0;
    end
    if numel(idx_gr_mask)>0
        green3(idx_gr_mask)=0;
    end
    
    if numel(idx_red_keep)>0
        red2(idx_red_keep)=0;
    end
    
    if numel(idx_red_mask)>0
        red3(idx_red_mask)=0;
    end
    
    %storing - green
    stackA(:,:,count3)=[gr_im,green2,green3];
    
    %storing - red
    stackB(:,:,count3)=[red_im,red2,red3];
    
    %iterate counter
    count3=count3+1;
    
    %clear statements
    clear green2; clear green3; clear red2; clear red3;
    clear idx_gr_keep; clear idx_gr_mask; clear idx_red_keep; clear idx_red_mask;clear gr_im; clear red_im;
     clear gr_perc_im; clear red_perc_im;
     
end

%Code for Imars
aTimeIndex=1;
aImarisApplication=handles.ImarisHoldIt;
vDataSet = aImarisApplication.GetFactory.CreateDataSet;
vDataSet.Create(Imaris.tType.eTypeUInt16,dim1b,dim2b,num_ims,2,1);
vDataSet.SetDataVolumeShorts(uint16(stackA),0, aTimeIndex-1);
vDataSet.SetDataVolumeShorts(uint16(stackB),1, aTimeIndex-1);
aImarisApplication.SetDataSet(vDataSet); 

%setting colorbar
aImarisApplication.GetDataSet.SetChannelColorRGBA(0,570475008) %green
aImarisApplication.GetDataSet.SetChannelColorRGBA(1,570622658) %red

%setting maxima
aImarisApplication.GetDataSet.SetChannelRange(0,0,high_green*0.7);%green
aImarisApplication.GetDataSet.SetChannelRange(1,0,high_red*0.7);%red


guidata(hObject, handles);


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%getting input from user
thresh_input=get(hObject,'String');
handles.ColocPercThresh=str2double(thresh_input);

guidata(hObject, handles);

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the 488nm cluster % button - rgb images

%image indices
the_start=handles.numstart;
the_end=handles.numend;

%top most directory - green channel
top_green_path=handles.TopDirectory;

%decision - overlap or within 1 pixel
dec_now=handles.OverlapYesNo;

if dec_now==1
   path_g=strcat(top_green_path,'\ColocalizationImages\PixelWiseColoc_Criteria1\Green\Percent Coloc\ImPerc'); 
else
    path_g=strcat(top_green_path,'\ColocalizationImages\PixelWiseColoc_Criteria2\Green\Percent Coloc\ImPerc');
end

%counter
count4=1;

%total number of images
tot_n_ims=the_end-the_start+1;

%debugging code
% test_dir='C:\Users\jeichorst\Desktop\New folder\';

for j=the_start:the_end
    
    %reading in the image
    im1=imread(strcat(path_g,num2str(j),'.tif'));
    im1=uint16(im1);
    
    %rgb rendering
    im1_rgb=make_rgb_blank(im1,100,3);
    
    %debugging code
    %imwrite(im1_rgb,strcat(test_dir,'im',num2str(j),'.tif'));
    
    if count4==1
    
        %dimensions
        dim1a=size(im1,1);
        dim2a=size(im1,2);
        
        %pre-allocating
        red_mat=zeros(dim1a,dim2a,tot_n_ims);
        %red_mat=uint16(red_mat);
        green_mat=red_mat;
        blue_mat=red_mat;
        
    end
    
%     if count4==20
%         figure, imagesc(im1,[0,100]); colormap(jet); colorbar;
%         figure, imshow(im1_rgb);
%     end
%         
    
    %loading
    red_mat(:,:,count4)=im1_rgb(:,:,1); %red
    green_mat(:,:,count4)=im1_rgb(:,:,2); %green
    blue_mat(:,:,count4)=im1_rgb(:,:,3); %blue
    
    %iterate counter
    count4=count4+1;
    
    %clear statements
    clear im1; clear im1_rgb;
    
end

  %making 8 bit integer matrices
    red_mat=red_mat*255;
    green_mat=green_mat*255;
    blue_mat=blue_mat*255;
    
    red_mat=uint16(red_mat);
    green_mat=uint16(green_mat);
    blue_mat=uint16(blue_mat);

%adding dataset to workspace
aTimeIndex=1;
aImarisApplication=handles.ImarisHoldIt;
vDataSet = aImarisApplication.GetFactory.CreateDataSet;
vDataSet.Create(Imaris.tType.eTypeFloat,dim1a,dim2a,tot_n_ims,3,1);
vDataSet.SetDataVolumeShorts(uint16(red_mat),0, aTimeIndex-1);
vDataSet.SetDataVolumeShorts(uint16(green_mat),1, aTimeIndex-1);
vDataSet.SetDataVolumeShorts(uint16(blue_mat),2, aTimeIndex-1);
aImarisApplication.SetDataSet(vDataSet); 
aImarisApplication.GetDataSet.SetChannelColorRGBA(0,570622658) %red
aImarisApplication.GetDataSet.SetChannelColorRGBA(1,570475008) %green
aImarisApplication.GetDataSet.SetChannelColorRGBA(2,583139329)  %blue

aImarisApplication.GetDataSet.SetChannelRange(0,0,255);%red
aImarisApplication.GetDataSet.SetChannelRange(1,0,255);%green
aImarisApplication.GetDataSet.SetChannelRange(2,0,255);%blue

guidata(hObject, handles);



% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the 642nm cluster % button - rgb images

%debugging code
% test_dir='C:\Users\jeichorst\Desktop\New folder\';

%image indices
the_start=handles.numstart;
the_end=handles.numend;

%top most directory - green channel
top_red_path=handles.TopDirectoryRed;

%decision - overlap or within 1 pixel
dec_now=handles.OverlapYesNo;

if dec_now==1
   path_r=strcat(top_red_path,'\ColocalizationImages\PixelWiseColoc_Criteria1\Red\Percent Coloc\ImPerc'); 
else
    path_r=strcat(top_red_path,'\ColocalizationImages\PixelWiseColoc_Criteria2\Red\Percent Coloc\ImPerc');
end

%counter
count4=1;

%total number of images
tot_n_ims=the_end-the_start+1;

for j=the_start:the_end
    
    %reading in the image
    im1=imread(strcat(path_r,num2str(j),'.tif'));
    im1=uint16(im1);
    
    %rgb rendering
    im1_rgb=make_rgb_blank(im1,100,3);
    
%     %debugging code only
%     imwrite(im1_rgb,strcat(test_dir,'im',num2str(j),'.tif'));
    
    if count4==1
    
        %dimensions
        dim1a=size(im1,1);
        dim2a=size(im1,2);
        
        %pre-allocating
        red_mat=zeros(dim1a,dim2a,tot_n_ims);
        %red_mat=uint16(red_mat);
        green_mat=red_mat;
        blue_mat=red_mat;
        
    end
    
    %loading
    red_mat(:,:,count4)=im1_rgb(:,:,1); %red
    green_mat(:,:,count4)=im1_rgb(:,:,2); %green
    blue_mat(:,:,count4)=im1_rgb(:,:,3); %blue
    
    %iterate counter
    count4=count4+1;
    
    %clear statements
    clear im1; clear im1_rgb;
    
end

%making 8 bit integer matrices
red_mat=red_mat*255;
green_mat=green_mat*255;
blue_mat=blue_mat*255;

red_mat=uint16(red_mat);
green_mat=uint16(green_mat);
blue_mat=uint16(blue_mat);


%adding dataset to workspace
aTimeIndex=1;
aImarisApplication=handles.ImarisHoldIt;
vDataSet = aImarisApplication.GetFactory.CreateDataSet;
vDataSet.Create(Imaris.tType.eTypeFloat,dim1a,dim2a,tot_n_ims,3,1);
vDataSet.SetDataVolumeShorts(uint16(red_mat),0, aTimeIndex-1);
vDataSet.SetDataVolumeShorts(uint16(green_mat),1, aTimeIndex-1);
vDataSet.SetDataVolumeShorts(uint16(blue_mat),2, aTimeIndex-1);
aImarisApplication.SetDataSet(vDataSet); 
aImarisApplication.GetDataSet.SetChannelColorRGBA(0,570622658) %red
aImarisApplication.GetDataSet.SetChannelColorRGBA(1,570475008) %green
aImarisApplication.GetDataSet.SetChannelColorRGBA(2,583139329)  %blue

aImarisApplication.GetDataSet.SetChannelRange(0,0,255);%red
aImarisApplication.GetDataSet.SetChannelRange(1,0,255);%green
aImarisApplication.GetDataSet.SetChannelRange(2,0,255);%blue

guidata(hObject, handles);

